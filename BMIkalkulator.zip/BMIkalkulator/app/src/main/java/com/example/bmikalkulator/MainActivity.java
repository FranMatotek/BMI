package com.example.bmikalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText Tezina, Visina;
    TextView resaults;
    String calculation, BMIresault;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Tezina = findViewById(R.id.Tezina);
        Visina = findViewById(R.id.Visina);
        resaults = findViewById(R.id.resault);

    }

    public void calculateBMI(View view) {

        String S1 = Tezina.getText().toString();
        String S2 = Visina.getText().toString();

        float TezinaValue = Float.parseFloat(S1);
        float VisinaValue = Float.parseFloat(S2) / 100;

        float bmi = TezinaValue / (VisinaValue * VisinaValue);

        if(bmi < 16){
            BMIresault = "Previse ishranjeni";
        }else if( bmi < 18.5){
            BMIresault = "Ispod pravilne kilaze";
        }else if(bmi >= 18.5 && bmi <=24.5){
            BMIresault = "Noramalna kilaza";

        }else if(bmi >=25 && bmi <= 29.9){
            BMIresault = "Malo prevelika kilaza";
        }else{
            BMIresault = "Pretilost";
        }

        calculation = "sesault:\n\n" + bmi + "\n" + BMIresault;
        resaults.setText(calculation);

    }
}